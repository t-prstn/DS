# DS Pocket Android starter

An Android Studio Kotlin/WebView shell with a file picker and an EmulatorJS melonDS front-end. This is a starter project, not a native emulator core or a tested APK.

## Open in Android Studio
1. Download and extract this project ZIP.
2. In Android Studio choose **Open** and select the `DSPocketAndroid` folder.
3. Allow Gradle sync to finish. Use JDK 17 or the JDK bundled with a current Android Studio.
4. Connect an Android device with USB debugging enabled, or start an emulator, then press **Run**.
5. Inside DS Pocket, choose the `.nds` file and tap **Start emulation**.

## Architecture
- Kotlin `MainActivity` creates a WebView and implements the Android document picker for HTML file input.
- `app/src/main/assets/index.html` reads the selected game into a browser Blob and boots EmulatorJS's `melonds` core.
- EmulatorJS engine files are loaded from `https://cdn.emulatorjs.org/stable/data/`, so first launch needs internet.

## Limitations / next engineering steps
- No emulator engine is bundled; the app depends on a third-party CDN and its availability/version.
- This scaffold has not been built or tested on a device in this environment.
- Some EmulatorJS cores may have browser/WebView limitations. If this approach is unstable, replace the WebView front-end with a properly licensed native emulator core and its Android integration.
- No BIOS/firmware or ROM files are included. Use files you are legally entitled to use.
- For production, add proper error reporting, lifecycle handling, orientation controls, save backup/export, and verify the core's terms and licensing.
