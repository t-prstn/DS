plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.dspocket"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.dspocket"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    // Pin Java and Kotlin to the same target so the build doesn't depend on
    // which JDK happens to be installed (JDK 17 or newer works).
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
